package sistemaAutogestion;

import dominio.Entrada;
import java.time.LocalDate;
import java.util.List;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.Assert;

public class IObligatorioTest {

    private Sistema miSistema;

    public IObligatorioTest() {

    }

    @Before
    public void setUp() {
        miSistema = new Sistema();
        miSistema.crearSistemaDeGestion();

    }

    @Test
    public void testCrearSistemaDeGestion() {

        Retorno retorno = miSistema.crearSistemaDeGestion();
        Assert.assertEquals(Retorno.Resultado.OK, retorno.getResultado());

    }

    @Test
    public void testRegistrarSala() {
        //OK
        Retorno resultado1 = miSistema.registrarSala("Sala 1", 50);
        assertEquals(Retorno.Resultado.OK, resultado1.getResultado());

        //Nombre duplicado
        Retorno resultado4 = miSistema.registrarSala("Sala 1", 35);
        assertEquals(Retorno.Resultado.ERROR_1, resultado4.getResultado());

        //Capacidad <= 0
        Retorno resultado2 = miSistema.registrarSala("Sala 2", 0);
        assertEquals(Retorno.Resultado.ERROR_2, resultado2.getResultado());

        //Capacidad negativa
        Retorno resultado3 = miSistema.registrarSala("Sala 3", -1);
        assertEquals(Retorno.Resultado.ERROR_2, resultado3.getResultado());

    }

    @Test
    public void testEliminarSala() {

        //Agrego Sala antes de eliminar
        Retorno resultadoRegistro = miSistema.registrarSala("Sala 1", 50);
        assertEquals(Retorno.Resultado.OK, resultadoRegistro.getResultado());

        //Elimino Sala que existe
        Retorno eliminarSala1 = miSistema.eliminarSala("Sala 1");
        assertEquals(Retorno.Resultado.OK, eliminarSala1.getResultado());

        // No elimina sala que no existe
        Retorno eliminarSala2 = miSistema.eliminarSala("Sala 2");
        assertEquals(Retorno.Resultado.ERROR_1, eliminarSala2.getResultado());

    }

    @Test
    public void testRegistrarEvento() {
        // Preparación: registrar salas en el sistema
        miSistema.registrarSala("Sala A", 100);
//        miSistema.registrarSala("Sala B", 50);

        // Caso 1: Registrar evento válido
        Retorno r1 = miSistema.registrarEvento("EV001", "Conferencia Java", 50, LocalDate.of(2025, 5, 15));
        assertEquals(Retorno.Resultado.OK, r1.getResultado());

        // Caso 2: Registrar evento con aforo no válido (<= 0)
        Retorno r2 = miSistema.registrarEvento("EV002", "Taller Python", -10, LocalDate.of(2025, 6, 20));
        assertEquals(Retorno.Resultado.ERROR_2, r2.getResultado());

        // Caso 3: Registrar evento en sala ocupada (Sala A ya usada el 15/5/2025, no hay otra sala con capacidad suficiente)
        Retorno r3 = miSistema.registrarEvento("EV003", "Evento 1", 100, LocalDate.of(2025, 5, 15));
        assertEquals(Retorno.Resultado.ERROR_3, r3.getResultado());

        // Caso 4: Registrar evento duplicado (mismo código EV001)
        Retorno r4 = miSistema.registrarEvento("EV001", "Evento duplicado", 40, LocalDate.of(2025, 7, 11));
        assertEquals(Retorno.Resultado.ERROR_1, r4.getResultado());

        // Caso 5: Registrar evento con aforo mayor que cualquier sala disponible (ninguna sala soporta 200)
        Retorno r5 = miSistema.registrarEvento("EV005", "Evento sin sala", 200, LocalDate.of(2025, 8, 1));
        assertEquals(Retorno.Resultado.ERROR_3, r5.getResultado());
    }

    @Test
    public void testRegistrarCliente() {
        // Cliente válido
        Retorno resultado1 = miSistema.registrarCliente("12345678", "Ana García");
        assertEquals(Retorno.Resultado.OK, resultado1.getResultado());

        // Cliente con cédula inválida (menos de 8 dígitos)
        Retorno resultado2 = miSistema.registrarCliente("1234567", "Luis Pérez");
        assertEquals(Retorno.Resultado.ERROR_1, resultado2.getResultado());

        // Cliente con cédula inválida (más de 8 dígitos)
        Retorno resultado3 = miSistema.registrarCliente("123456789", "Mario Gómez");
        assertEquals(Retorno.Resultado.ERROR_1, resultado3.getResultado());

        // Cliente con caracteres en la cédula
        Retorno resultado4 = miSistema.registrarCliente("123456a8", "Carlos Ríos");
        assertEquals(Retorno.Resultado.ERROR_1, resultado4.getResultado());

        // Cliente duplicado (misma cédula que el primero)
        Retorno resultado5 = miSistema.registrarCliente("12345678", "Carlos Ríos");
        assertEquals(Retorno.Resultado.ERROR_2, resultado5.getResultado());

        // Cliente con cédula null
        Retorno resultado6 = miSistema.registrarCliente(null, "Nombre Desconocido");
        assertEquals(Retorno.Resultado.ERROR_1, resultado6.getResultado());

        // Cliente con nombre vacío (válido si no se valida el nombre)
        Retorno resultado7 = miSistema.registrarCliente("87654321", "");
        assertEquals(Retorno.Resultado.OK, resultado7.getResultado());

        // Varios clientes válidos diferentes
        Retorno resultado8 = miSistema.registrarCliente("11112222", "Juan");
        assertEquals(Retorno.Resultado.OK, resultado8.getResultado());

        Retorno resultado9 = miSistema.registrarCliente("22223333", "Lucía");
        assertEquals(Retorno.Resultado.OK, resultado9.getResultado());

        Retorno resultado10 = miSistema.registrarCliente("33334444", "Marta");
        assertEquals(Retorno.Resultado.OK, resultado10.getResultado());
    }

    @Test
    public void testListarSalas() {
        // Registro salas
        miSistema.registrarSala("Sala A", 10);
        miSistema.registrarSala("Sala B", 20);
        miSistema.registrarSala("Sala C", 30);
        Retorno resultado3 = miSistema.listarSalas();
        assertEquals(Retorno.Resultado.OK, resultado3.getResultado());

    }

    @Test
    public void testListarEventos() {
        // 1. Lista vacía de eventos
        Retorno r1 = miSistema.listarEventos();
        assertEquals(Retorno.Resultado.OK, r1.getResultado());
        assertEquals("", r1.getValorString()); // o "\n" si devuelve un salto

        // 2. Un solo evento
        miSistema.registrarEvento("E001", "Charla de IA", 50, LocalDate.parse("2025-10-01"));
        Retorno r2 = miSistema.listarEventos();
        assertEquals(Retorno.Resultado.OK, r2.getResultado());
        

        // 3. Varios eventos
        miSistema.registrarEvento("E002", "Taller UX", 30,LocalDate.parse("2025-10-02"));
        miSistema.registrarEvento("E003", "Bootcamp Dev", 100,LocalDate.parse("2025-10-03"));
        Retorno r3 = miSistema.listarEventos();
        assertEquals(Retorno.Resultado.OK, r3.getResultado());
        
    }

    @Test
    public void testListarClientes() {
        // Registro de clientes
        miSistema.registrarCliente("12345678", "Ana García");
        miSistema.registrarCliente("98765432", "Luis Pérez");
        miSistema.registrarCliente("11223344", "Carlos Ríos");
        
        Retorno resultado = miSistema.listarClientes();
        assertEquals(Retorno.Resultado.OK, resultado.resultado);
    }

    @Test
    public void testEsSalaOptima() {
        // Caso óptimo
        String[][] salaOptima = {
            {"#", "#", "#", "#", "#", "#", "#"},
            {"#", "#", "X", "X", "X", "X", "#"},
            {"#", "O", "O", "X", "X", "X", "#"},
            {"#", "O", "O", "O", "O", "X", "#"},
            {"#", "O", "O", "X", "O", "O", "#"},
            {"#", "O", "O", "O", "O", "O", "#"},
            {"#", "X", "X", "O", "O", "O", "O"},
            {"#", "X", "X", "O", "O", "O", "X"},
            {"#", "X", "X", "O", "X", "X", "#"},
            {"#", "X", "X", "O", "X", "X", "#"},
            {"#", "#", "#", "O", "#", "#", "#"},
            {"#", "#", "#", "O", "#", "#", "#"}
        };
        Retorno resultado1 = miSistema.esSalaOptima(salaOptima);
        assertEquals(Retorno.Resultado.OK, resultado1.getResultado());

        // Caso no óptimo
        String[][] salaNoOptima = {
            {"X", "X", "O"},
            {"O", "X", "O"},
            {"X", "O", "X"},
            {"X", "X", "O"}
        };
        Retorno resultado2 = miSistema.esSalaOptima(salaNoOptima);
        assertEquals(Retorno.Resultado.OK, resultado2.getResultado());

        // Matriz vacía
        String[][] vacia = new String[0][0];
        Retorno resultado3 = miSistema.esSalaOptima(vacia);
        assertEquals(Retorno.Resultado.ERROR_1, resultado3.getResultado());

        // Matriz nula
        String[][] nula = null;
        Retorno resultado4 = miSistema.esSalaOptima(nula);
        assertEquals(Retorno.Resultado.ERROR_1, resultado4.getResultado());

        // Justo dos columnas óptimas
        String[][] justoDos = {
            {"O", "O", "X"},
            {"O", "O", "X"},
            {"O", "X", "O"},
            {"O", "X", "O"},
            {"O", "O", "O"},
            {"O", "O", "X"}
        };
        Retorno resultado5 = miSistema.esSalaOptima(justoDos);
        assertEquals(Retorno.Resultado.OK, resultado5.getResultado());
    }

    @Test
    public void testComprarEntrada() {
        // Configuración inicial
        miSistema.registrarSala("Sala A", 100);

        miSistema.registrarCliente("11111111", "Cliente 1");
        miSistema.registrarCliente("22222222", "Cliente 2");
        miSistema.registrarCliente("33333333", "Cliente 3");
        miSistema.registrarCliente("44444444", "Cliente 4");

        // Registrar evento con aforo 2
        miSistema.registrarEvento("E001", "Concierto", 2, LocalDate.of(2025, 6, 10));

        // Caso 1: Cliente no existe
        Retorno caso1 = miSistema.comprarEntrada("99999999", "E001");
        assertEquals(Retorno.Resultado.ERROR_1, caso1.getResultado());

        // Caso 2: Evento no existe
        miSistema.registrarCliente("12345678", "Cliente 1");
        Retorno caso2 = miSistema.comprarEntrada("12345678", "ZZZ");
        assertEquals(Retorno.Resultado.ERROR_2, caso2.getResultado());

        // Caso 3: Compra válida - Cliente 1
        Retorno caso3 = miSistema.comprarEntrada("11111111", "E001");
        assertEquals(Retorno.Resultado.OK, caso3.getResultado());

        // Caso 4: Compra válida - Cliente 2
        Retorno caso4 = miSistema.comprarEntrada("22222222", "E001");
        assertEquals(Retorno.Resultado.OK, caso4.getResultado());

        // Caso 5: Aforo completo - Cliente 3 agregado a lista de espera
        Retorno caso5 = miSistema.comprarEntrada("33333333", "E001");
        assertEquals(Retorno.Resultado.OK, caso5.getResultado());

        // Caso 6: Cliente 1 compra una entrada adicional → aforo ya lleno → lista de espera
        Retorno caso6 = miSistema.comprarEntrada("11111111", "E001");
        assertEquals(Retorno.Resultado.OK, caso6.getResultado());

        // Caso 7: Cliente 4 también a lista de espera
        Retorno caso7 = miSistema.comprarEntrada("44444444", "E001");
        assertEquals(Retorno.Resultado.OK, caso7.getResultado());

    }

    @Test
    public void testDevolverEntrada() {
        // Caso 1: Cliente no existe
        Retorno resultado1 = miSistema.devolverEntrada("99999999", "E001");
        assertEquals(Retorno.Resultado.ERROR_1, resultado1.getResultado());

        // Caso 2: Evento no existe
        miSistema.registrarCliente("12345678", "Juan Perez");
        Retorno resultado2 = miSistema.devolverEntrada("12345678", "E999");
        assertEquals(Retorno.Resultado.ERROR_2, resultado2.getResultado());

        // Caso 3: Cliente devuelve entrada sin lista de espera
        miSistema.registrarSala("Sala A", 100);
        miSistema.registrarEvento("E001", "Charla UX", 10, LocalDate.of(2025, 5, 10));
        miSistema.registrarCliente("56789012", "Juan Perez");
        miSistema.comprarEntrada("56789012", "E001");
        Retorno resultado5 = miSistema.devolverEntrada("56789012", "E001");
        assertEquals(Retorno.Resultado.OK, resultado5.getResultado());
    }

//    @Test
//    public void testDeshacerUltimasCompras() {
//        // Preparación previa: agregar algunas entradas para poder borrar
//        miSistema.comprarEntrada("123", "EVT1");
//        miSistema.comprarEntrada("456", "EVT2");
//        miSistema.comprarEntrada("789", "EVT3");
//
//        // Caso OK: deshacer 2 compras
//        Retorno resultado1 = miSistema.deshacerUtimasCompras(2);
//        assertEquals(Retorno.Resultado.OK, resultado1.getResultado());
//
//        // Caso ERROR_1: pedir deshacer 0 compras (n <= 0)
//        Retorno resultado2 = miSistema.deshacerUtimasCompras(0);
//        assertEquals(Retorno.Resultado.ERROR_1, resultado2.getResultado());
//
//        // Caso ERROR_2: deshacer cuando la lista de entradas está vacía
//        // Vaciar la pila primero
//        miSistema.deshacerUtimasCompras(10); // borra todo lo que queda
//
//        Retorno resultado3 = miSistema.deshacerUtimasCompras(1);
//        assertEquals(Retorno.Resultado.ERROR_2, resultado3.getResultado());
//
//        // Caso OK: pedir deshacer más de las entradas que existen (solo se deshacen las que hay)
//        // Primero, agregamos 1 entrada
//        miSistema.comprarEntrada("111", "EVT4");
//        Retorno resultado4 = miSistema.deshacerUtimasCompras(5); // solo hay 1 entrada
//        assertEquals(Retorno.Resultado.OK, resultado4.getResultado());
//    }
    @Test
    public void testListarClientesDeEvento() {

        miSistema.registrarCliente("12345678", "Ramiro Perez");
        miSistema.registrarCliente("45666666", "Micaela Ferrez");
        miSistema.registrarCliente("78999999", "Juan López");

        miSistema.registrarSala("Sala A", 100);
        miSistema.registrarEvento("E1", "Evento 1", 50, LocalDate.of(2025, 6, 10));

        // Registrar entradas válidas
        miSistema.comprarEntrada("12345678", "E1");
        miSistema.comprarEntrada("45666666", "E1");
        miSistema.comprarEntrada("78999999", "E1");

        // OK - listar 2 últimos clientes
        Retorno resultado1 = miSistema.listarClientesDeEvento("E1", 2);
        assertEquals(Retorno.Resultado.OK, resultado1.getResultado());

        // OK - listar más de los clientes que hay (debería mostrar todos sin error)
        Retorno resultado2 = miSistema.listarClientesDeEvento("E1", 10);
        assertEquals(Retorno.Resultado.OK, resultado2.getResultado());

        // ERROR_1 - el evento no existe
        Retorno resultado3 = miSistema.listarClientesDeEvento("NO_EXISTE", 2);
        assertEquals(Retorno.Resultado.ERROR_1, resultado3.getResultado());

        // ERROR_2 - n < 1
        Retorno resultado4 = miSistema.listarClientesDeEvento("E1", 0);
        assertEquals(Retorno.Resultado.ERROR_2, resultado4.getResultado());

        Retorno resultado5 = miSistema.listarClientesDeEvento("E1", -1);
        assertEquals(Retorno.Resultado.ERROR_2, resultado5.getResultado());
    }

    @Test
    public void testEliminarEvento() {
        // Registrar cliente
        miSistema.registrarCliente("12345678", "Ana García");

        // Registrar salas (solo código y capacidad)
        miSistema.registrarSala("S1", 50);
        miSistema.registrarSala("S2", 100);

        // Registrar eventos
        miSistema.registrarEvento("E001", "Concierto", 40, LocalDate.of(2025, 6, 10));
        miSistema.registrarEvento("E002", "Conferencia", 80, LocalDate.of(2025, 6, 10));

        // Eliminar evento existente
        Retorno resultado1 = miSistema.eliminarEvento("E001");
        assertEquals(Retorno.Resultado.OK, resultado1.getResultado());

        // Intentar eliminar evento que ya fue eliminado
        Retorno resultado3 = miSistema.eliminarEvento("E001");
        assertEquals(Retorno.Resultado.ERROR_1, resultado3.getResultado());

        // Intentar eliminar evento inexistente
        Retorno resultado4 = miSistema.eliminarEvento("E999");
        assertEquals(Retorno.Resultado.ERROR_1, resultado4.getResultado());

        miSistema.registrarCliente("12345688", "Ana García");
        miSistema.registrarEvento("E002", "Conferencia", 80, LocalDate.of(2025, 6, 10));
        miSistema.comprarEntrada("12345678", "E002");  // Venta de entrada para E002
        Retorno resultadoNoElimina = miSistema.eliminarEvento("E002");
        assertEquals(Retorno.Resultado.ERROR_2, resultadoNoElimina.getResultado());

    }

    @Test
    public void testComprasXDia() {
        // Inicializar sistema
        miSistema.crearSistemaDeGestion();

        // Registrar sala y evento para mayo
        miSistema.registrarSala("Sala C", 50);
        LocalDate fechaEvento = LocalDate.of(2025, 5, 1);
        miSistema.registrarEvento("EVT3", "Evento Mayo", 50, fechaEvento);

        // Registrar clientes
        miSistema.registrarCliente("10101010", "Hugo");
        miSistema.registrarCliente("20202020", "Isabel");
        miSistema.registrarCliente("30303030", "Jorge");

        // Comprar entradas
        miSistema.comprarEntrada("10101010", "EVT3");
        miSistema.comprarEntrada("20202020", "EVT3");
        miSistema.comprarEntrada("30303030", "EVT3");

        // Modificar fechas para simular compras en distintos días de mayo
        miSistema.modificarFechaEntrada("10101010", "EVT3", LocalDate.of(2025, 5, 10));
        miSistema.modificarFechaEntrada("20202020", "EVT3", LocalDate.of(2025, 5, 10));
        miSistema.modificarFechaEntrada("30303030", "EVT3", LocalDate.of(2025, 5, 25));

        // Ejecutar método para mayo (mes 5)
        Retorno resultado = miSistema.comprasXDia(5);

        // Validaciones
        assertEquals(Retorno.Resultado.OK, resultado.getResultado());

    }

    @Test
    public void testComprasDeCliente() {

        // Registrar sala y evento
        miSistema.registrarSala("Sala A", 100);
        miSistema.registrarEvento("E1", "Concierto", 50, LocalDate.of(2025, 6, 20));

        // Registrar clientes
        miSistema.registrarCliente("12345678", "Ana");
        miSistema.registrarCliente("87654321", "Luis");
        miSistema.registrarCliente("88888888", "Alfonso");

        // Comprar entradas
        miSistema.comprarEntrada("12345678", "E1"); // Ana
        miSistema.comprarEntrada("87654321", "E1"); // Luis

        // Simular devolución de la entrada de Luis
        miSistema.devolverEntrada("87654321", "E1");

        // Cliente con 1 entrada NO devuelta
        Retorno resultado1 = miSistema.comprasDeCliente("12345678");
        assertEquals(Retorno.Resultado.OK, resultado1.getResultado());

        // Cliente con 1 entrada devuelta
        Retorno resultado2 = miSistema.comprasDeCliente("87654321");
        assertEquals(Retorno.Resultado.OK, resultado2.getResultado());

        // Cliente sin compras
        Retorno resultado3 = miSistema.comprasDeCliente("88888888");
        assertEquals(Retorno.Resultado.OK, resultado3.getResultado());

        // Cliente inexistente
        Retorno resultado4 = miSistema.comprasDeCliente("99999999");
        assertEquals(Retorno.Resultado.ERROR_1, resultado4.getResultado());
    }

//    @Test
//    public void testListarEsperaEventoConVariosEventos() {
//        Sistema sistema = new Sistema();
//        sistema.crearSistemaDeGestion();
//
//        // Registrar salas
//        sistema.registrarSala("Sala 1", 1);
//        sistema.registrarSala("Sala 2", 1);
//
//        // Registrar clientes
//        sistema.registrarCliente("12345678", "Cliente Uno");
//        sistema.registrarCliente("87654321", "Cliente Dos");
//        sistema.registrarCliente("55555555", "Cliente Tres");
//
//        // Registrar eventos
//        LocalDate fecha = LocalDate.of(2025, 6, 10);
//        sistema.registrarEvento("E001", "Evento Uno", 1, fecha);
//        sistema.registrarEvento("E002", "Evento Dos", 1, fecha);
//
//        // Cliente 1 compra entrada para E001 (aforo 1)
//        Retorno compra1 = sistema.comprarEntrada("12345678", "E001");
//        assertEquals(Retorno.Resultado.OK, compra1.resultado);
//
//        // Cliente 2 intenta comprar entrada para E001 (queda en espera)
//        Retorno compra2 = sistema.comprarEntrada("87654321", "E001");
//        assertEquals(Retorno.Resultado.OK, compra2.resultado);
//
//        // Cliente 3 compra entrada para E002 (aforo 1)
//        Retorno compra3 = sistema.comprarEntrada("55555555", "E002");
//        assertEquals(Retorno.Resultado.OK, compra3.resultado);
//
//        // Cliente 1 intenta comprar entrada para E002 (queda en espera)
//        Retorno compra4 = sistema.comprarEntrada("12345678", "E002");
//        assertEquals(Retorno.Resultado.OK, compra4.resultado);
//
//        // Listar eventos con lista de espera
//        Retorno espera = sistema.listarEsperaEvento();
//        assertEquals(Retorno.Resultado.OK, espera.resultado);
//
//    }
    @Test
    public void testListarEsperaEventoOrdenado() {
        Sistema sistema = new Sistema();
        sistema.crearSistemaDeGestion();

        sistema.registrarSala("Sala 1", 1);
        sistema.registrarSala("Sala 2", 1);

        sistema.registrarCliente("87654321", "Cliente Dos");
        sistema.registrarCliente("12345678", "Cliente Uno");
        sistema.registrarCliente("55555555", "Cliente Tres");
        sistema.registrarCliente("33333333", "Cliente Cuatro");
        sistema.registrarCliente("99999999", "Cliente Cinco");

        LocalDate fecha = LocalDate.of(2025, 6, 10);
        sistema.registrarEvento("E002", "Evento Dos", 1, fecha);
        sistema.registrarEvento("E001", "Evento Uno", 1, fecha);

        sistema.comprarEntrada("12345678", "E001"); // OK
        sistema.comprarEntrada("87654321", "E001"); // espera
        sistema.comprarEntrada("55555555", "E001"); // espera

        sistema.comprarEntrada("33333333", "E002"); // OK
        sistema.comprarEntrada("99999999", "E002"); // espera
        sistema.comprarEntrada("12345678", "E002"); // espera

        Retorno espera = sistema.listarEsperaEvento();
        assertEquals(Retorno.Resultado.OK, espera.resultado);

    }

    @Test
    public void testCalificarEvento() {
        // Registrar sala y evento
        miSistema.registrarSala("Sala A", 100);
        miSistema.registrarEvento("E1", "Concierto", 50, LocalDate.of(2025, 6, 20));

        // Registrar clientes
        miSistema.registrarCliente("12345678", "Juan");
        miSistema.registrarCliente("87654321", "Ana");

        // Comprar entradas (simula que asistieron)
        miSistema.comprarEntrada("12345678", "E1");
        miSistema.comprarEntrada("87654321", "E1");

        // cliente califica por primera vez
        Retorno r1 = miSistema.calificarEvento("12345678", "E1", 8, "Muy bueno");
        assertEquals(Retorno.Resultado.OK, r1.getResultado());

        //el cliente ya calificó ese evento
        Retorno r2 = miSistema.calificarEvento("12345678", "E1", 9, "Excelente");
        assertEquals(Retorno.Resultado.ERROR_4, r2.getResultado());

        // cliente no existe
        Retorno r3 = miSistema.calificarEvento("999", "E1", 7, "Bueno");
        assertEquals(Retorno.Resultado.ERROR_1, r3.getResultado());

        // evento no existe
        Retorno r4 = miSistema.calificarEvento("12345678", "NO_EXISTE", 7, "Bueno");
        assertEquals(Retorno.Resultado.ERROR_2, r4.getResultado());

        // puntaje < 1
        Retorno r5 = miSistema.calificarEvento("12345678", "E1", 0, "Malo");
        assertEquals(Retorno.Resultado.ERROR_3, r5.getResultado());

        // puntaje > 10
        Retorno r6 = miSistema.calificarEvento("12345678", "E1", 11, "Excelente");
        assertEquals(Retorno.Resultado.ERROR_3, r6.getResultado());

        //otro cliente califica por primera vez
        Retorno r7 = miSistema.calificarEvento("87654321", "E1", 10, "Perfecto");
        assertEquals(Retorno.Resultado.OK, r7.getResultado());
    }

    @Test
    public void testEventoMejorPuntuado() {
        // Registro salas
        miSistema.registrarSala("Sala A", 100);
        miSistema.registrarSala("Sala B", 80);

        // Registro eventos
        miSistema.registrarEvento("E1", "Concierto", 50, LocalDate.of(2025, 6, 20));
        miSistema.registrarEvento("E2", "Teatro", 30, LocalDate.of(2025, 7, 10));
        miSistema.registrarEvento("E3", "Charla", 40, LocalDate.of(2025, 8, 5));

        // Registro clientes
        miSistema.registrarCliente("12345678", "Juan");
        miSistema.registrarCliente("87654321", "Ana");
        miSistema.registrarCliente("55555555", "Luis");

        // Comprar entradas (simula asistencia)
        miSistema.comprarEntrada("12345678", "E1");
        miSistema.comprarEntrada("87654321", "E1");
        miSistema.comprarEntrada("55555555", "E2");
        miSistema.comprarEntrada("12345678", "E3");

        // Calificar eventos
        miSistema.calificarEvento("12345678", "E1", 8, "Muy bueno");
        miSistema.calificarEvento("87654321", "E1", 9, "Excelente");
        miSistema.calificarEvento("55555555", "E2", 10, "Perfecto");
        miSistema.calificarEvento("12345678", "E3", 10, "Excelente");

        // Llamar a eventoMejorPuntuado
        Retorno r = miSistema.eventoMejorPuntuado();

        // Debe ser OK
        assertEquals(Retorno.Resultado.OK, r.getResultado());
    }

    @Test
    public void testDeshacerUltimasCompras() {
        // Preparar eventos y agregarlos a la lista
        miSistema.registrarSala("Sala A", 100);
        miSistema.registrarEvento("E1", "Concierto", 10, LocalDate.of(2025, 6, 20));
        miSistema.registrarEvento("E2", "Teatro", 5, LocalDate.of(2025, 7, 15));

        // Agregar entradas
        miSistema.comprarEntrada("12345678", "E1");
        miSistema.comprarEntrada("87654321", "E1");
        miSistema.comprarEntrada("55555555", "E2");
        miSistema.comprarEntrada("12345678", "E3");

        // Caso 1: deshacer 2 últimas compras
        Retorno r1 = miSistema.deshacerUtimasCompras(2);
        assertEquals(Retorno.Resultado.OK, r1.getResultado());

        // Caso 2: deshacer más compras que las que hay
        Retorno r2 = miSistema.deshacerUtimasCompras(5);
        assertEquals(Retorno.Resultado.OK, r2.getResultado());

    }

}
