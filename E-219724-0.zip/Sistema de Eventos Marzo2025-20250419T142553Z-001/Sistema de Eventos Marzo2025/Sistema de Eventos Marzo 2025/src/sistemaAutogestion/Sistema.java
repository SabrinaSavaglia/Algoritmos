package sistemaAutogestion;

import dominio.Cliente;
import dominio.Evento;
import dominio.Sala;
import dominio.Entrada;
import java.time.LocalDate;
import java.util.List;
import tads.Cola;
import tads.ListaNodos;
import tads.UtilClientes;
import tads.UtilEntradas;
import tads.UtilEventos;

public class Sistema implements IObligatorio {

    private ListaNodos<Sala> lista;
    private ListaNodos<Cliente> listaClientes;
    private ListaNodos<Evento> listaEventos;
    private Cola<Entrada> listaEntradas;

    @Override
    public Retorno crearSistemaDeGestion() {
        lista = new ListaNodos();
        listaClientes = new ListaNodos();
        listaEventos = new ListaNodos();
        listaEntradas = new Cola<>();

        return Retorno.ok();

    }

    @Override
    public Retorno esVacia() {
        if (lista == null) {
            return new Retorno(Retorno.Resultado.OK);
        }
        return new Retorno(Retorno.Resultado.OK);
    }

    @Override
    public Retorno Vaciar() {
        lista = new ListaNodos<>();
        return Retorno.ok();
    }

    @Override
    public Retorno registrarSala(String nombre, int capacidad) {
        Sala s1 = new Sala(nombre, capacidad);
        Retorno r = new Retorno(Retorno.Resultado.NO_IMPLEMENTADA);

        // capacidad
        if (capacidad <= 0) {
            r.resultado = Retorno.Resultado.ERROR_2;
        } else if (lista.existeElemento(s1)) {
            r.resultado = Retorno.Resultado.ERROR_1;
        } else {
            lista.agregarInicio(s1);
            r.resultado = Retorno.Resultado.OK;
        }

        return r;
    }

    @Override
    public Retorno eliminarSala(String nombre) {
        Sala s1 = new Sala(nombre);
        Retorno r = new Retorno(Retorno.Resultado.NO_IMPLEMENTADA);

        if (lista.eliminar(s1)) {
            r.resultado = Retorno.Resultado.OK;
        } else {
            r.resultado = Retorno.Resultado.ERROR_1;
        }

        return r;
    }

    @Override
    public Retorno registrarCliente(String cedula, String nombre) {

        Retorno r = new Retorno(Retorno.Resultado.NO_IMPLEMENTADA);

        // Validar cédula antes de crear el objeto Cliente
        if (cedula == null || !cedula.matches("\\d{8}")) {
            r.resultado = Retorno.Resultado.ERROR_1;
        } else {
            Cliente c1 = new Cliente(cedula, nombre);
            if (listaClientes.existeElemento(c1)) {
                r.resultado = Retorno.Resultado.ERROR_2;
            } else {
                listaClientes.agregarOrdenado(c1);
                r.resultado = Retorno.Resultado.OK;
            }
        }

        return r;
    }

    @Override
    public Retorno registrarEvento(String codigo, String descripcion, int aforoNecesario, LocalDate fecha) {
        Retorno r = new Retorno(Retorno.Resultado.NO_IMPLEMENTADA);

        // Validar aforo
        if (aforoNecesario <= 0) {
            r.resultado = Retorno.Resultado.ERROR_2;
            return r;
        }

        // Verificar evento duplicado
        Evento eventoTemp = new Evento(codigo, descripcion, aforoNecesario, fecha, null);
        if (listaEventos.existeElemento(eventoTemp)) {
            r.resultado = Retorno.Resultado.ERROR_1;
            return r;
        }

        // Buscar sala disponible con capacidad suficiente
        Sala salaDisponible = null;
        for (Sala sala : lista.obtenerElementos()) {
            if (sala.getCapacidad() >= aforoNecesario && sala.estaDisponible(fecha)) {
                salaDisponible = sala;
                break;
            }
        }

        if (salaDisponible == null) {
            r.resultado = Retorno.Resultado.ERROR_3; // No hay sala disponible
            return r;
        }

        // Crear y agregar el evento
        Evento nuevoEvento = new Evento(codigo, descripcion, aforoNecesario, fecha, salaDisponible);
        listaEventos.agregarOrdenado(nuevoEvento);
        salaDisponible.agregarEvento(nuevoEvento);

        r.resultado = Retorno.Resultado.OK;
        return r;
    }

    @Override
    public Retorno listarSalas() {
        String salas = lista.mostrar(); // debe retornar un String
        return new Retorno(Retorno.Resultado.OK, salas);
    }

    @Override
    public Retorno listarEventos() {
        String eventos = listaEventos.mostrar(); // debe retornar un String
        return new Retorno(Retorno.Resultado.OK, eventos);

    }

    @Override
    public Retorno listarClientes() {
        String clientes = listaClientes.mostrar(); // debe retornar un String
        return new Retorno(Retorno.Resultado.OK, clientes);

    }

    @Override
    public Retorno esSalaOptima(String[][] vistaSala) {
        try {
            String resultado = Sala.esSalaOptima(vistaSala);
            return new Retorno(Retorno.Resultado.OK, resultado);
        } catch (Exception e) {
            return new Retorno(Retorno.Resultado.ERROR_1);
        }
    }

    @Override
    public Retorno comprarEntrada(String cedula, String codigoEvento) {
        Retorno r = new Retorno(Retorno.Resultado.NO_IMPLEMENTADA);

        Cliente c1 = new Cliente(cedula);
        Cliente clienteReal = listaClientes.obtenerElemento(c1);
        if (clienteReal == null) {
            r.resultado = Retorno.Resultado.ERROR_1;
            return r;
        }

        Evento e1 = new Evento(codigoEvento);
        Evento eventoReal = listaEventos.obtenerElemento(e1);
        if (eventoReal == null) {
            r.resultado = Retorno.Resultado.ERROR_2; // Evento no existe
            return r;
        }
        Entrada ent1 = new Entrada(codigoEvento, cedula);

        int entradasVendidas = UtilEntradas.contarEntradasPorEvento(listaEntradas.toList(), codigoEvento);

        if (entradasVendidas < eventoReal.getAforoNecesario()) {
            listaEntradas.encolar(ent1);
            //  System.out.println("Entrada agregada: " + ent1);
            r.resultado = Retorno.Resultado.OK;
        } else {
            eventoReal.agregarAListaEspera(clienteReal); // Cliente agregado a lista de espera;
            r.resultado = Retorno.Resultado.OK;
        }

        return r;
    }

    @Override
    public Retorno eliminarEvento(String codigo) {
        Retorno r = new Retorno(Retorno.Resultado.NO_IMPLEMENTADA);

        Evento eventoAEliminar = new Evento(codigo);
        Evento eventoReal = listaEventos.obtenerElemento(eventoAEliminar);

        if (eventoReal == null) {
            r.resultado = Retorno.Resultado.ERROR_1; // El evento no existe
            return r;
        }

        int entradasVendidas = UtilEntradas.contarEntradasPorEvento(listaEntradas.toList(), codigo);
        if (entradasVendidas > 0) {
            r.resultado = Retorno.Resultado.ERROR_2; // El evento tiene entradas vendidas
            return r;
        }

        Sala salaAsignada = eventoReal.getSala();
        if (salaAsignada != null) {
            salaAsignada.eliminarEvento(eventoReal);
        }

        // Eliminar el evento de la lista usando el objeto real
        listaEventos.eliminar(eventoReal);
        r.resultado = Retorno.Resultado.OK;
        return r;
    }

    @Override
    public Retorno listarEsperaEvento() {
        String resultado = UtilEventos.obtenerEventosConEsperaOrdenados(listaEventos);
//        System.out.println("Eventos con lista de espera: " + resultado);
        return new Retorno(Retorno.Resultado.OK, resultado.trim());
    }

    @Override
    public Retorno devolverEntrada(String cedula, String codigoEvento) {
        Retorno r = new Retorno(Retorno.Resultado.NO_IMPLEMENTADA);

        Cliente clienteTemp = new Cliente(cedula);
        if (!listaClientes.existeElemento(clienteTemp)) {
            return new Retorno(Retorno.Resultado.ERROR_1);  // Cliente no existe
        }

        Evento eventoTemp = listaEventos.obtenerElemento(new Evento(codigoEvento));
        if (eventoTemp == null) {
            return new Retorno(Retorno.Resultado.ERROR_2);  // Evento no existe
        }

        Entrada entrada = listaEntradas.obtenerEntrada(cedula, codigoEvento);

        if (entrada == null || entrada.fueDevuelta()) {
            return new Retorno(Retorno.Resultado.ERROR_3);
        }

        entrada.marcarComoDevuelta();

        // Reasignar si hay alguien en lista de espera
        if (eventoTemp.getListaEspera() != null && !eventoTemp.getListaEspera().esVacia()) {
            Cliente siguiente = eventoTemp.getListaEspera().obtenerPrimero();
            Entrada nuevaEntrada = new Entrada(codigoEvento, siguiente.getCedula());
            listaEntradas.encolar(nuevaEntrada);
            eventoTemp.getListaEspera().eliminar(siguiente);
        }

        return new Retorno(Retorno.Resultado.OK);
    }

    @Override
    public Retorno calificarEvento(String cedula, String codigoEvento,
            int puntaje, String comentario) {

        Retorno r = new Retorno(Retorno.Resultado.NO_IMPLEMENTADA);

        Cliente buscado = new Cliente(cedula);
        if (!listaClientes.existeElemento(buscado)) {
            r.resultado = Retorno.Resultado.ERROR_1;
            return r;
        }

        Evento eventoBuscado = new Evento(codigoEvento);
        if (!listaEventos.existeElemento(eventoBuscado)) {
            r.resultado = Retorno.Resultado.ERROR_2;
            return r;
        }
        Evento buscadoEvento = listaEventos.obtenerElemento(eventoBuscado);

        if (puntaje < 1 || puntaje > 10) {
            r.resultado = Retorno.Resultado.ERROR_3;
            return r;
        }

        if (buscadoEvento.yaFueCalificadoPor(cedula)) {
            r.resultado = Retorno.Resultado.ERROR_4;
            return r;
        }

        buscadoEvento.agregarCalificacion(cedula, puntaje, comentario);
        r.resultado = Retorno.Resultado.OK;
        return r;
    }

    @Override
    public Retorno eventoMejorPuntuado() {
        String resultado = UtilEventos.eventosConMejorPromedioConPuntajeString(listaEventos);
//        System.out.println("Resultado Evento mejor Puntuado" + resultado);
        return new Retorno(Retorno.Resultado.OK, resultado);
    }

    @Override
    public Retorno comprasDeCliente(String cedula) {
        Cliente buscado = new Cliente(cedula);

        if (!listaClientes.existeElemento(buscado)) {
            return new Retorno(Retorno.Resultado.ERROR_1);
        }

        // Convertir la cola a lista
        List<Entrada> entradas = listaEntradas.toList();

        String resultado = UtilClientes.comprasDeCliente(buscado, entradas);

        //System.out.println("Compras de Cliente: " + resultado);
        return new Retorno(Retorno.Resultado.OK, resultado);
    }

    @Override
    public Retorno comprasXDia(int mes) {
        Retorno r = new Retorno(Retorno.Resultado.NO_IMPLEMENTADA);

        if (mes < 1 || mes > 12) {
            r.resultado = Retorno.Resultado.ERROR_1;
            return r;
        }

        List<Entrada> entradas = listaEntradas.toList();

        String detalle = UtilEntradas.comprasPorDiaDelMes(entradas, mes);
        r.valorString = detalle;
        r.resultado = Retorno.Resultado.OK;
        System.out.println("Por dia Compras: " + r.valorString);

        return r;
    }

    public Retorno agregarEvento(String codigo, String descripcion, int aforoNecesario, LocalDate fecha, Sala sala) {
        Evento nuevoEvento = new Evento(codigo, descripcion, aforoNecesario, fecha, sala);

        if (listaEventos.existeElemento(nuevoEvento)) {
            return new Retorno(Retorno.Resultado.ERROR_1, "Evento ya existente");
        }

        listaEventos.agregarInicio(nuevoEvento); // O agregarOrdenado si querés mantener orden

        return new Retorno(Retorno.Resultado.OK, "Evento agregado correctamente");
    }

    @Override
    public Retorno listarClientesDeEvento(String codigoEvento, int n) {
        Retorno r = new Retorno(Retorno.Resultado.NO_IMPLEMENTADA);

        if (n < 1) {
            r.resultado = Retorno.Resultado.ERROR_2; // n < 1
            return r;
        }

        Evento evento = buscarEventoPorCodigo(codigoEvento);
        if (evento == null) {
            r.resultado = Retorno.Resultado.ERROR_1; // evento no existe
            return r;
        }

        // Convertir la cola de entradas a lista
        List<Entrada> entradas = this.listaEntradas.toList();

        UtilClientes util = new UtilClientes();

        //llamamos a quien retorna el string
        String clientesListados = util.listarClientesDeEvento(codigoEvento, n, entradas, cedula -> buscarClientePorCedula(cedula));

        r.resultado = Retorno.Resultado.OK;
        r.valorString = clientesListados;

//        System.out.println("Clientes listados para evento " + codigoEvento + ": " + clientesListados);
        return r;
    }

    public Evento buscarEventoPorCodigo(String codigo) {
        for (Evento ev : listaEventos.toList()) {
            if (ev.getCodigo().equals(codigo)) {
                return ev;
            }
        }
        return null;
    }

    public Cliente buscarClientePorCedula(String cedula) {
        for (Cliente c : listaClientes.toList()) {
            if (c.getCedula().equals(cedula)) {
                return c;
            }
        }
        return null;
    }

    @Override
    public Retorno deshacerUtimasCompras(int n) {
        Retorno r = new Retorno(Retorno.Resultado.NO_IMPLEMENTADA);

        r.valorString = listaEntradas.deshacerUltimasCompras(n, listaEventos);
        r.resultado = Retorno.Resultado.OK;
        return r;
    }

    public boolean modificarFechaEntrada(String cedula, String codigoEvento, LocalDate nuevaFecha) {
        for (Entrada e : listaEntradas.toList()) {
            if (e.getCedulaCliente().equals(cedula) && e.getCodigoEvento().equals(codigoEvento)) {
                e.setFecha(nuevaFecha);
                return true;
            }
        }
        return false;
    }

}
