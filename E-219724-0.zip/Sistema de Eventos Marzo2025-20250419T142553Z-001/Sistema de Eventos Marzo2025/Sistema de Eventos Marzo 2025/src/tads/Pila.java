package tads;

import dominio.Cliente;
import dominio.Entrada;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Pila<T extends Comparable> implements IPila<T> {

    private NodoLista<T> pila;
    private int cantidad;

    public Pila() {
        this.pila = null;
        this.cantidad = 0;
    }

    @Override
    public void push(T x) {
        if (cantidad == 0) { // Es el primer nodo
            NodoLista nuevo = new NodoLista(x);
            nuevo.setSiguiente(null);
            pila = nuevo;
        } else {
            NodoLista nuevo = new NodoLista(x);
            nuevo.setSiguiente(pila);
            pila = nuevo;
        }
        cantidad++;
    }

    @Override
    public T top() {
        return this.pila.getDato();
    }

    @Override
    public int cantidadElementos() {
        return cantidad;
    }

    @Override
    public boolean esVacia() {
        return pila == null;
    }

    @Override
    public void vaciar() {
        cantidad = 0;
        pila = null;
    }

//    @Override
//    public void pop() {
//        if(cantidad == 1){
//            vaciar();
//        }else if(!esVacia()){
//            NodoLista aBorrar = pila;
//            pila = pila.getSiguiente();
//            aBorrar.setSiguiente(null);
//            cantidad--;
//        }
//    }
//    
// 
    @Override//aca lo modifique a tipo T en vez de ser void//ATENCION
    public T pop() {
        if (esVacia()) {
            return null;
        }

        T dato = pila.getDato();
        pila = pila.getSiguiente();
        cantidad--;

        return dato;
    }

    public boolean existeElemento(T x) {
        NodoLista<T> aux = pila;

        while (aux != null) {
            if (aux.getDato().equals(x)) {
                return true;
            }
            aux = aux.getSiguiente();
        }

        return false;
    }

   

    

}
