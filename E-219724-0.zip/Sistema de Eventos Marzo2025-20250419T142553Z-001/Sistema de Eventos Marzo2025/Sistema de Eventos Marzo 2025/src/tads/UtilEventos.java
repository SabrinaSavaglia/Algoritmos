package tads;

import dominio.Evento;
import dominio.Cliente;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class UtilEventos {

    public static String eventosConMejorPromedioConPuntajeString(ListaNodos<Evento> lista) {
        List<Evento> mejores = new ArrayList<>();
        double mejorPromedio = -1;

        NodoLista<Evento> nodo = lista.getInicio();
        while (nodo != null) {
            Evento e = nodo.getDato();
            double promedio = e.calcularPromedioPuntaje();

            if (promedio > mejorPromedio) {
                mejores.clear();
                mejores.add(e);
                mejorPromedio = promedio;
            } else if (promedio == mejorPromedio) {
                mejores.add(e);
            }

            nodo = nodo.getSiguiente();
        }

        mejores.sort(Comparator.comparing(Evento::getCodigo));

        StringBuilder sb = new StringBuilder();
        for (Evento e : mejores) {
            sb.append(e.getCodigo()).append("-").append(e.calcularPromedioPuntaje()).append("#");
        }

        return sb.toString().trim();  // trim para eliminar la última línea vacía
    }

    public static String obtenerEventosConEsperaOrdenados(ListaNodos<Evento> lista) {
        List<Evento> eventos = lista.toList();
        // Ordenar eventos alfabéticamente por código, en la misma lista
        eventos.sort(Comparator.comparing(Evento::getCodigo));

        StringBuilder resultado = new StringBuilder();

        for (Evento e : eventos) {
            Cola<Cliente> listaEspera = e.getListaEspera();
            if (listaEspera != null && !listaEspera.esVacia()) {
                List<Cliente> clientesEspera = listaEspera.toList();

                // Ordenar clientes por cédula
                clientesEspera.sort(Comparator.comparing(Cliente::getCedula));

                // Construir string con cédulas separados por #
                for (Cliente c : clientesEspera) {
                    resultado.append(e.getCodigo()).append("-").append(c.getCedula()).append("#");
                }
            }
        }

        return resultado.toString();
    }

}
