package tads;

import dominio.Entrada;
import java.time.LocalDate;
import java.util.List;

public class UtilEntradas {

    public static int contarEntradasPorEvento(List<Entrada> entradas, String codigoEvento) {
        int contador = 0;

        for (Entrada entrada : entradas) {
            if (entrada.getCodigoEvento().equals(codigoEvento)) {
                contador++;
            }
        }

        return contador;
    }

    public static String comprasPorDiaDelMes(List<Entrada> entradas, int mes) {
        int[] conteo = new int[32]; // índice de 1 a 31

        for (Entrada entrada : entradas) {
            LocalDate fecha = entrada.getFecha();
            if (fecha != null && fecha.getMonthValue() == mes) {
                int dia = fecha.getDayOfMonth();
                conteo[dia]++;
            }
        }

        StringBuilder sb = new StringBuilder();
        for (int dia = 1; dia <= 31; dia++) {
            if (conteo[dia] > 0) {
                if (sb.length() > 0) {
                    sb.append("#");
                }
                sb.append(dia).append("-").append(conteo[dia]);
            }
        }

        return sb.length() > 0 ? sb.toString() : "No hay compras en ese mes";
    }
    
    

}
