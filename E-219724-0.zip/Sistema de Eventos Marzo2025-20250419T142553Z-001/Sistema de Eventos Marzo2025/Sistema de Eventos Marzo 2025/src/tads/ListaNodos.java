package tads;

import dominio.Cliente;
import dominio.Entrada;
import dominio.Sala;
import dominio.Evento;
import java.time.LocalDate;
import java.util.List;
import java.util.ArrayList;
import java.util.Comparator;

public class ListaNodos<T extends Comparable> implements IListaSimple<T> {

    private NodoLista<T> inicio;
    private int cantElementos;

    public ListaNodos() {
        this.inicio = null;
        cantElementos = 0;
    }

    public boolean esVacia() {
        return inicio == null;
    }

    public NodoLista<T> getInicio() {
        return this.inicio;
    }

    @Override
    public void agregarInicio(T x) {
        if (cantElementos == 0) { // Es el primer nodo
            NodoLista nuevo = new NodoLista(x);
            nuevo.setSiguiente(null);
            inicio = nuevo;

        } else {
            NodoLista nuevo = new NodoLista(x);
            nuevo.setSiguiente(inicio);
            inicio = nuevo;
        }
        cantElementos++;
    }

    @Override
    public boolean existeElemento(T x) {
        NodoLista<T> aux = inicio;

        while (aux != null) {
            if (aux.getDato().equals(x)) {
                return true;
            }
            aux = aux.getSiguiente();
        }
        return false;
    }

//    @Override
//    public boolean eliminar(T x) {
//        boolean existe = false;
//        NodoLista<T> aux = inicio;
//
//        while (aux != null && !existe) {
//            if (aux.getDato().equals(x)) {
//                existe = true;
//                NodoLista<T> sig = aux.getSiguiente();
//                if (sig != null) {
//
//                    aux.setDato(sig.getDato());
//
//                    aux.setSiguiente(sig.getSiguiente());
//                }
//
//            }
//            aux = aux.getSiguiente();
//        }
//        return existe;
//    }
//    @Override
//    public boolean eliminar(T x) {
//        if (inicio == null) {
//            return false;
//        }
//
//        // Si el nodo a eliminar es el primero
//        if (inicio.getDato().equals(x)) {
//            inicio = inicio.getSiguiente();
//            cantElementos--;
//            return true;
//        }
//
//        NodoLista<T> actual = inicio;
//        while (actual.getSiguiente() != null) {
//            if (actual.getSiguiente().getDato().equals(x)) {
//                // saltar el nodo siguiente
//                actual.setSiguiente(actual.getSiguiente().getSiguiente());
//                cantElementos--;
//                return true;
//            }
//            actual = actual.getSiguiente();
//        }
//
//        return false;  // no encontrado
//    }
    @Override
    public boolean eliminar(T x) {
        NodoLista<T> actual = inicio;
        NodoLista<T> anterior = null;

        while (actual != null) {
            if (actual.getDato().equals(x)) {
                if (anterior == null) {
                    // Eliminar el primer nodo
                    inicio = actual.getSiguiente();
                } else {
                    // Eliminar nodo que no es el primero
                    anterior.setSiguiente(actual.getSiguiente());
                }
                cantElementos--;
                return true;
            }
            anterior = actual;
            actual = actual.getSiguiente();
        }

        return false; // no encontrado
    }

    @Override
    public String mostrar() {
        StringBuilder resultado = new StringBuilder();
        NodoLista<T> aux = inicio;

        while (aux != null) {
            resultado.append(aux.getDato().toString());
            aux = aux.getSiguiente();
        }

        return resultado.toString();
    }

    @Override
    public void agregarOrdenado(T x) {
        if (esVacia() || x.compareTo(inicio.getDato()) < 0) {
            agregarInicio(x);
            return;
        }

        NodoLista<T> aux = inicio;
        while (aux.getSiguiente() != null && x.compareTo(aux.getSiguiente().getDato()) > 0) {
            aux = aux.getSiguiente();
        }

        NodoLista<T> nuevo = new NodoLista<>(x);
        nuevo.setSiguiente(aux.getSiguiente());
        aux.setSiguiente(nuevo);
    }

    private boolean estaOcupada(Sala sala, LocalDate fecha, ListaNodos<Evento> listaEventos) {
        NodoLista<Evento> actual = listaEventos.getInicio();

        while (actual != null) {
            Evento evento = actual.getDato();
            if (evento.getSala().equals(sala) && evento.getFecha().equals(fecha)) {
                return true;
            }

            actual = actual.getSiguiente();
        }

        return false;
    }

    public T obtenerElemento(T x) {
        NodoLista<T> aux = inicio;
        while (aux != null) {
            if (aux.getDato().equals(x)) {
                return aux.getDato();
            }
            aux = aux.getSiguiente();
        }
        return null; // no encontrado
    }

    public List<T> obtenerElementos() {
        List<T> elementos = new ArrayList<>();
        NodoLista<T> aux = inicio;
        while (aux != null) {
            elementos.add(aux.getDato());
            aux = aux.getSiguiente();
        }
        return elementos;
    }

    public T obtenerPrimero() {
        if (inicio != null) {
            return inicio.getDato();
        }
        return null;  // si la lista está vacía
    }

//    public void push(Entrada e1) {
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
//    }
//    public List<Evento> eventosConMejorPromedio() {
//        List<Evento> resultado = new ArrayList<>();
//
//        NodoLista<Evento> actual = (NodoLista<Evento>) this.getInicio();
//        double maxPromedio = -1;
//
//        while (actual != null) {
//            Evento evento = actual.getDato();
//            double promedio = evento.calcularPromedioPuntaje();
//
//            if (promedio > maxPromedio) {
//                maxPromedio = promedio;
//                resultado.clear();
//                resultado.add(evento);
//            } else if (promedio == maxPromedio) {
//                resultado.add(evento);
//            }
//
//            actual = actual.getSiguiente();
//        }
//
//        resultado.sort(Comparator.comparing(Evento::getCodigo));
//        return resultado;
//    }
    public List<T> toList() {
        List<T> lista = new ArrayList<>();
        NodoLista<T> actual = this.inicio; // Asumiendo que tenés un atributo `inicio`

        while (actual != null) {
            lista.add(actual.getDato());
            actual = actual.getSiguiente();
        }

        return lista;
    }

//    public String obtenerEventosConEsperaOrdenados() {
//        List<Evento> eventos = (List<Evento>) this.toList(); 
//        eventos.sort(Comparator.comparing(e -> ((Evento) e).getCodigo()));
//
//        String resultado = "";
//        for (Evento e : eventos) {
//            if (((Evento) e).getListaEspera() != null && !((Evento) e).getListaEspera().esVacia()) {
//                resultado += ((Evento) e).getCodigo() + "-";
//
//                List<Cliente> clientes = ((Evento) e).getListaEspera().toList();
//                clientes.sort(Comparator.comparing(Cliente::getCedula));
//
//                for (Cliente c : clientes) {
//                    resultado += c.getCedula() + "#";
//                }
//            }
//        }
//
//        return resultado;
//    }
}
