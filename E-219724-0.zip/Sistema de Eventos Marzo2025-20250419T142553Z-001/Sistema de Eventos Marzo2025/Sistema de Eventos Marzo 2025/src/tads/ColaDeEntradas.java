package tads;

import dominio.Entrada;
import dominio.Evento;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class ColaDeEntradas extends Cola<Entrada> {

    public String deshacerUltimasCompras(int n, ListaNodos<Evento> listaEventos) {
        // Paso 1: Obtener todas las entradas de la cola
        List<Entrada> entradas = this.toList();

        // Paso 2: Ajustar n si es más grande que la cantidad total
        if (n > entradas.size()) {
            n = entradas.size();
        }

        // Paso 3: Elegimos las últimas 'n' entradas
        List<Entrada> aDeshacer = entradas.subList(entradas.size() - n, entradas.size());

        // Paso 4: Por cada entrada, buscar el evento y devolver la cantidad
        for (Entrada e : aDeshacer) {
            for (Evento ev : listaEventos.toList()) {
                if (ev.getCodigo().equals(e.getCodigoEvento())) {
                    ev.incrementarCantidad();
                    break;
                }
            }
        }

        // Paso 5: Crear una nueva cola con las entradas que NO se deshicieron
        Cola<Entrada> nuevaCola = new Cola<>();
        for (int i = 0; i < entradas.size() - n; i++) {
            nuevaCola.encolar(entradas.get(i));
        }

        // Paso 6: Reemplazar la cola actual por la nueva
        this.reemplazarCon(nuevaCola);

        // Paso 7: Ordenar las entradas deshechas y armar el texto con StringBuilder
        aDeshacer.sort(Comparator
            .comparing(Entrada::getCodigoEvento)
            .thenComparing(Entrada::getCedulaCliente));

        StringBuilder sb = new StringBuilder();
        for (Entrada e : aDeshacer) {
            sb.append(e.getCodigoEvento())
              .append("-").append(e.getCedulaCliente())
              .append("#");
        }

        return sb.toString().trim();
    }
}
