package tads;

import dominio.Cliente;
import dominio.Entrada;
import dominio.Evento;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Stack;
import java.util.function.Function;

public class Cola<T extends Comparable> implements ICola<T> {

    private NodoLista<T> cola;
    private NodoLista<T> fin;
    private int cantidad;

    public Cola() {
        this.cola = null;
        this.cantidad = 0;
    }

    public boolean esVacia() {
        return cola == null;
    }

    @Override
    public void encolar(T x) {
        NodoLista nuevo = new NodoLista(x);
        if (isEmpty()) {
            this.cola = nuevo;
            this.fin = nuevo;
        } else {
            fin.setSiguiente(nuevo);
            fin = fin.getSiguiente();
        }
        cantidad++;
    }

    @Override
    public void desencolar() {
        if (cantidad == 1) {
            vaciar();
        } else if (!isEmpty()) {
            NodoLista aBorrar = cola;
            cola = cola.getSiguiente();
            aBorrar.setSiguiente(null);
            cantidad--;
        }
    }

    @Override
    public T front() {
        if (!this.isEmpty()) {
            return this.cola.getDato();
        }
        return null;
    }

    @Override
    public boolean isEmpty() {
        return cola == null;
    }

    @Override
    public void vaciar() {
        cantidad = 0;
        cola = null;
        fin = null;
    }

    @Override
    public int cantidadElementos() {
        return cantidad;
    }

    public List<T> toList() {
        List<T> lista = new ArrayList<>();
        NodoLista<T> actual = this.cola; // Asumiendo que tenés un atributo `inicio`

        while (actual != null) {
            lista.add(actual.getDato());
            actual = actual.getSiguiente();
        }

        return lista;
    }

    @Override
    public void mostrar() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public boolean existeElemento(T elemento) {
        NodoLista<T> actual = cola;
        while (actual != null) {
            if (actual.getDato().equals(elemento)) {
                return true;
            }
            actual = actual.getSiguiente();
        }
        return false;
    }

    public T obtenerPrimero() {
        if (!this.esVacia()) {
            return this.cola.getDato(); // Devuelve el primer elemento sin eliminarlo
        }
        return null; // Retorna null si la cola está vacía
    }

    public void eliminar(T elemento) {
        if (esVacia()) {
            return;
        }

        NodoLista<T> actual = cola;
        NodoLista<T> anterior = null;

        while (actual != null) {
            if (actual.getDato().equals(elemento)) {
                if (anterior == null) {
                    cola = actual.getSiguiente(); // Eliminar el primer nodo
                } else {
                    anterior.setSiguiente(actual.getSiguiente()); // Eliminar nodo intermedio
                }
                cantidad--;
                return;
            }
            anterior = actual;
            actual = actual.getSiguiente();
        }
    }

   
//    public List<Entrada> comprasDeCliente(Cliente cliente) {
//        List<Entrada> resultado = new ArrayList<>();
//        NodoLista<T> actual = cola;
//
//        while (actual != null) {
//            Entrada entrada = (Entrada) actual.getDato();
//            if (entrada.getCedulaCliente().equals(cliente.getCedula())) {
//                resultado.add(entrada);
//            }
//            actual = actual.getSiguiente();
//        }
//        return resultado;
//    }
    
    

    public Entrada obtenerEntrada(String cedula, String codigoEvento) {
        NodoLista<T> actual = cola;

        while (actual != null) {
            if (actual.getDato() instanceof Entrada) {
                Entrada entrada = (Entrada) actual.getDato();
                if (entrada.getCedulaCliente().equals(cedula)
                        && entrada.getCodigoEvento().equals(codigoEvento)) {
                    return entrada;
                }
            }
            actual = actual.getSiguiente();
        }
        return null;
    }

        public void reemplazarCon(Cola<T> otra) {
        this.vaciar();
        List<T> elementos = otra.toList();
        for (T e : elementos) {
            this.encolar(e);
        }
    }


    public String deshacerUltimasCompras(int n, ListaNodos<Evento> listaEventos) {

    // Obtener una lista genérica de los elementos actuales en la cola
    List<T> entradasGenericas = this.toList();

    // Crear una pila para procesar las entradas desde el final (últimas compras)
    Stack<Entrada> pila = new Stack<>();

    // Filtrar y apilar solo las instancias de Entrada
    for (T t : entradasGenericas) {
        if (t instanceof Entrada) {
            pila.push((Entrada) t);
        }
    }

    // Lista que almacenará las entradas que vamos a deshacer
    List<Entrada> aDeshacer = new ArrayList<>();

    // Limitar n a la cantidad total de elementos si es mayor
    int total = pila.size();
    n = Math.min(n, total);

    // Desapilar las últimas n entradas (las últimas compras realizadas)
    for (int i = 0; i < n; i++) {
        Entrada entrada = pila.pop();     // Tomar una entrada de la pila
        aDeshacer.add(entrada);           // Guardarla para luego mostrarla
        Evento evento = buscarEventoPorCodigo(listaEventos, entrada.getCodigoEvento()); // Buscar el evento correspondiente
        if (evento != null) {
            evento.incrementarCantidad(); // Devolver el cupo del evento (entrada deshecha)
        }
    }

    // Crear una nueva cola con las entradas restantes (las que no se deshicieron)
    Cola<Entrada> nuevaCola = new Cola<>();

    // Pila auxiliar para invertir el orden de las entradas restantes
    Stack<Entrada> auxiliar = new Stack<>();

    // Invertimos la pila original para mantener el orden original de la cola
    while (!pila.isEmpty()) {
        auxiliar.push(pila.pop());
    }

    // Pasamos los elementos en el orden correcto a la nueva cola
    while (!auxiliar.isEmpty()) {
        nuevaCola.encolar(auxiliar.pop());
    }

    // Reemplazamos la cola original con la nueva (que no contiene las entradas deshechas)
    this.reemplazarCon((Cola<T>) nuevaCola);

    // Ordenamos las entradas deshechas primero por código de evento, luego por cédula de cliente
    aDeshacer.sort(Comparator
            .comparing(Entrada::getCodigoEvento)
            .thenComparing(Entrada::getCedulaCliente));

    // Armamos el string de respuesta concatenando evento-cedula#
    StringBuilder sb = new StringBuilder();
    for (Entrada e : aDeshacer) {
        sb.append(e.getCodigoEvento())       // Código del evento
          .append("-").append(e.getCedulaCliente()) // Cédula del cliente
          .append("#");                      // Separador
    }

    // Devolvemos el string final con los datos de las entradas deshechas
    return sb.toString().trim(); // trim por si queda un espacio o separador al final
}


    private Evento buscarEventoPorCodigo(ListaNodos<Evento> listaEventos, String codigo) {
        for (Evento ev : listaEventos.toList()) {
            if (ev.getCodigo().equals(codigo)) {
                return ev;
            }
        }
        return null;
    }

   }
