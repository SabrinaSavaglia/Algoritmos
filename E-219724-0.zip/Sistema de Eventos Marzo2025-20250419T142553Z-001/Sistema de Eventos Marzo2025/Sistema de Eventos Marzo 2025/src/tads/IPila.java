package tads;

public interface IPila<T> {

    void push(T x);

    T top();

    int cantidadElementos();

    boolean esVacia();

    void vaciar();

    T pop();

//    void mostrar();
}
