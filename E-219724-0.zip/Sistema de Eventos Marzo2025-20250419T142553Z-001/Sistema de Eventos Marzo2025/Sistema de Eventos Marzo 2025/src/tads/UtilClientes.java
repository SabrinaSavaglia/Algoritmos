package tads;

import dominio.Cliente;
import dominio.Entrada;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;

public class UtilClientes {

    public static String listarClientesDeEvento(String codigoEvento, int n, List<Entrada> entradas,Function<String, Cliente> buscarClientePorCedulaFunc) {

        List<Entrada> entradasEvento = new ArrayList<>();

        for (Entrada entrada : entradas) {
            if (codigoEvento.equals(entrada.getCodigoEvento())) {
                entradasEvento.add(entrada);// todas las que tienen mismo codigo
            }
        }

        List<Entrada> ultimasEntradas = entradasEvento.subList( //size, (cantidad de entradas totales)
                Math.max(0, entradasEvento.size() - n),// indice del inicio, ejemplo entradasEvento.size() - n = 10 - 3 = 7, muestra del 7 al 10(ultimas 3)
                entradasEvento.size()// indice final
        );

        StringBuilder sb = new StringBuilder();

        for (Entrada e : ultimasEntradas) {
            Cliente c = buscarClientePorCedulaFunc.apply(e.getCedulaCliente());
            if (c == null) continue;

            if (sb.length() > 0) sb.append("#");
            sb.append(c.getCedula()).append("-").append(c.getNombre());
        }

        return sb.toString();
    }
    
    
   public static String comprasDeCliente(Cliente cliente, List<Entrada> entradas) {
    StringBuilder sb = new StringBuilder();

    for (Entrada entrada : entradas) {
        if (entrada.getCedulaCliente().equals(cliente.getCedula())) {
            sb.append(entrada.getCodigoEvento().trim())
              .append("-")
              .append(entrada.fueDevuelta() ? "D" : "N")
              .append("#");
        }
    }

    return sb.toString();
}


}
