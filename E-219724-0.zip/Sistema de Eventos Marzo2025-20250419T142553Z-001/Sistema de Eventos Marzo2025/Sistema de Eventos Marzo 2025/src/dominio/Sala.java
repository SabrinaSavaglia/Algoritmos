package dominio;

import java.time.LocalDate;
import tads.ListaNodos;
import tads.NodoLista;

public class Sala implements Comparable<Sala> {

    private String nombre;
    private int capacidad;
    private ListaNodos<Evento> eventos;

    public Sala(String nombre, int capacidad) {
        this.nombre = nombre;
        this.capacidad = capacidad;
        this.eventos = new ListaNodos<>();
    }

    public Sala(String nombre) {
        this.nombre = nombre;

    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getCapacidad() {
        return capacidad;
    }

    public void setCapacidad(int capacidad) {
        this.capacidad = capacidad;
    }

    public ListaNodos<Evento> getEventos() {
        return eventos;
    }

    @Override
    public boolean equals(Object obj) {
        Sala s = (Sala) obj;
        return s.nombre.equals(this.nombre);
    }

    @Override
    public String toString() {
        return this.nombre + "-" + this.capacidad + "#";
    }

    @Override
    public int compareTo(Sala o) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public static String esSalaOptima(String[][] vistaSala) {
        int columnas = vistaSala[0].length;
        int filas = vistaSala.length;
        int columnasOptimas = 0;

        for (int col = 0; col < columnas; col++) {
            int maxOcupadosConsecutivos = 0;
            int ocupadosConsecutivosActual = 0;
            int libres = 0;

            for (int fila = 0; fila < filas; fila++) {
                String valor = vistaSala[fila][col];

                if (valor.equals("O")) {
                    ocupadosConsecutivosActual++;
                    maxOcupadosConsecutivos = Math.max(maxOcupadosConsecutivos, ocupadosConsecutivosActual);
                } else {
                    ocupadosConsecutivosActual = 0;
                    if (valor.equals("X")) {
                        libres++;
                    }
                }
            }

            if (maxOcupadosConsecutivos > libres) {
                columnasOptimas++;
            }
        }

        return columnasOptimas >= 2 ? "Es óptimo" : "No es óptimo";
    }

    public boolean estaDisponible(LocalDate fecha) {
        NodoLista<Evento> actual = eventos.getInicio();
        if (actual == null) {
            // No hay eventos en la lista, por lo que la sala está disponible
            return true;
        }
        while (actual != null) {
            if (actual.getDato().getFecha().equals(fecha)) {
                return false; // Ya hay un evento en esa fecha
            }
            actual = actual.getSiguiente();
        }
        return true;
    }

    public void agregarEvento(Evento e) {
        eventos.agregarOrdenado(e);

    }

    public boolean eliminarEvento(Evento evento) {
        return eventos.eliminar(evento);
    }

}
