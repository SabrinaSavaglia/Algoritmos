package dominio;

public class Calificacion {
    private String cedulaCliente;
    private int puntaje;
    private String comentario;

    public Calificacion(String cedulaCliente, int puntaje, String comentario) {
        this.cedulaCliente = cedulaCliente;
        this.puntaje = puntaje;
        this.comentario = comentario;
    }

    public String getCedulaCliente() {
        return cedulaCliente;
    }

    public int getPuntaje() {
        return puntaje;
    }

    public String getComentario() {
        return comentario;
    }
}
