package dominio;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import tads.Cola;

public class Evento implements Comparable<Evento> {

    private String codigo;
    private String descripcion;
    private int aforoNecesario;
    private LocalDate fecha;
    private Sala sala; // Sala asignada al evento
    private List<Calificacion> calificaciones = new ArrayList<>();
    private Cola<Cliente> listaEspera;
    private int cantidad;

    public Evento(String codigo, String descripcion, int aforoNecesario, LocalDate fecha, Sala sala) {
        this.codigo = codigo;
        this.descripcion = descripcion;
        this.aforoNecesario = aforoNecesario;
        this.fecha = fecha;
        this.sala = sala;
        this.listaEspera = new Cola<>();
        this.cantidad = 0;

    }

    public Evento(String codigo) {
        this.codigo = codigo;
        this.descripcion = "";
        this.aforoNecesario = 0;
        this.fecha = null;
        this.sala = null;
        this.listaEspera = new Cola<>();

    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public int getAforoNecesario() {
        return aforoNecesario;
    }

    public void setAforoNecesario(int aforoNecesario) {
        this.aforoNecesario = aforoNecesario;
    }

    public LocalDate getFecha() {
        return fecha;
    }

    public void setFecha(LocalDate fecha) {
        this.fecha = fecha;
    }

    public Sala getSala() {
        return sala;
    }

    public void setSala(Sala sala) {
        this.sala = sala;
    }

    @Override
    public boolean equals(Object obj) {
        Evento e = (Evento) obj;
        return e.codigo.equals(this.codigo);
    }

    @Override
    public String toString() {
        return this.codigo + "-" + this.descripcion + "-" + this.sala;
    }

    public String toStringConPromedio() {
        return this.codigo + "-" + String.format("%.1f", this.calcularPromedioPuntaje()) + "#";// sin decimales
    }
    


    @Override
    public int compareTo(Evento e) {
        return this.codigo.trim().compareTo(e.getCodigo().trim());
    }

    public boolean yaFueCalificadoPor(String cedula) {
        for (Calificacion c : calificaciones) {
            if (c.getCedulaCliente().equals(cedula)) {
                return true;
            }
        }
        return false;
    }

    public void agregarCalificacion(String cedula, int puntaje, String comentario) {
        calificaciones.add(new Calificacion(cedula, puntaje, comentario));
    }

    public double calcularPromedioPuntaje() {
        if (calificaciones.isEmpty()) {
            return 0;
        }

        double suma = 0;
        for (Calificacion c : calificaciones) {
            suma += c.getPuntaje();
        }
        return suma / calificaciones.size(); // si el objeto tiene 5 calificaciones es lo que devuelve
    }

    public Cola<Cliente> getListaEspera() {
        return this.listaEspera;
    }

    public void agregarAListaEspera(Cliente c) {
        if (!listaEspera.existeElemento(c)) {
            listaEspera.encolar(c);
        }
    }

    @Override
    public int hashCode() {
        return codigo.hashCode();
    }

    public void incrementarCantidad() {
        this.cantidad++;
    }

}
