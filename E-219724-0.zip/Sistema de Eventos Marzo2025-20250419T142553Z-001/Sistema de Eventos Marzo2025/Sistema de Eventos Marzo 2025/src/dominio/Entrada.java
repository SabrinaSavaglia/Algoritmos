package dominio;

import java.time.LocalDate;

public class Entrada implements Comparable<Entrada> {

    private String codigoEvento;
    private String cedulaCliente;
    private LocalDate fecha;
    private boolean devuelta;

    // Constructor con fecha actual por defecto
    public Entrada(String codigoEvento, String cedulaCliente) {
        this(codigoEvento, cedulaCliente, LocalDate.now());
    }

    // Constructor para asignar fecha explícita
    public Entrada(String codigoEvento, String cedulaCliente, LocalDate fecha) {
        this.codigoEvento = codigoEvento;
        this.cedulaCliente = cedulaCliente;
        this.fecha = fecha;
        this.devuelta = false;
    }

    public String getCodigoEvento() {
        return codigoEvento;
    }

    public void setCodigoEvento(String codigoEvento) {
        this.codigoEvento = codigoEvento;
    }

    public String getCedulaCliente() {
        return cedulaCliente;
    }

    public void setCedulaCliente(String cedulaCliente) {
        this.cedulaCliente = cedulaCliente;
    }

    public LocalDate getFecha() {
        return fecha;
    }

    public void setFecha(LocalDate fecha) {
        this.fecha = fecha;
    }

    public boolean fueDevuelta() {
        return devuelta;
    }

    public void marcarComoDevuelta() {
        this.devuelta = true;
    }

    @Override
    public String toString() {
        return "Evento: " + codigoEvento + ", Cliente: " + cedulaCliente + ", Fecha: " + fecha + ", Devuelta: " + devuelta;
    }

    @Override
    public boolean equals(Object obj) {
        Entrada e = (Entrada) obj;
        return e.cedulaCliente.equals(this.cedulaCliente) && e.codigoEvento.equals(this.codigoEvento);
    }

    @Override
    public int hashCode() {
        return cedulaCliente.hashCode() + codigoEvento.hashCode();
    }

     @Override
    public int compareTo(Entrada o) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
